# 📋 ZETA v0.6 — Полный План Реализации

**Кодовое название:** `ZETA 0.6 — Universal Mobile + Grand Features`
**Дата:** 2026-02-11
**Цель:** Идеально адаптированный под любой телефон web-app с грандиозными новыми функциями

---

## 🏗️ ЧАСТЬ 1: Универсальная Мобильная Адаптация

> **Приоритет: МАКСИМАЛЬНЫЙ** — Ничего не должно выходить за границы экрана

### 1.1 Глобальный CSS Reset для мобильных (`style.css`)
- [ ] Добавить `overflow-x: hidden` на `html` и `body` с `!important`
- [ ] Заменить все `100vh` на `100dvh` (dynamic viewport height) — решает баг iOS Safari
- [ ] Добавить `width: 100dvw; max-width: 100%;` на все контейнеры
- [ ] Добавить Safe Area поддержку для iPhone с "чёлкой" (notch)
- [ ] Все `position: fixed` элементы — проверить на выход за границы

### 1.2 Breakpoints — Поддержка всех экранов
Текущие breakpoints: `768px`, `480px`, `360px`
**Добавить:**
- [ ] `@media (max-width: 320px)` — iPhone SE / самые маленькие экраны
- [ ] `@media (max-height: 600px)` — ландшафтные телефоны или маленькие экраны
- [ ] `@media (min-width: 481px) and (max-width: 768px)` — планшеты в портрете
- [ ] `@media (orientation: landscape) and (max-height: 500px)` — телефон горизонтально

### 1.3 Tab Bar (нижняя навигация)
- [ ] Убедиться что tab-bar не закрывает контент (padding-bottom на body = высота tab-bar)
- [ ] Добавить safe-area-inset-bottom для iPhone
- [ ] Tab-bar показывать на всех экранах до `768px` (не только до `480px`)

### 1.4 Hero Section
- [ ] `min-height: auto` на мобильных (вместо `min-height: 220px`)
- [ ] Кнопки Hero — `flex-wrap: wrap` чтобы не выходили за экран
- [ ] Уменьшить шрифт заголовка на экранах `<360px`

### 1.5 Crypto Section — Полная мобильная адаптация
- [ ] Crypto-card: убрать фиксированные px-размеры, использовать `%` и `rem`
- [ ] Search input: `width: 100%` на мобильных с `box-sizing: border-box`
- [ ] Market Details Panel: `max-width: 100%; overflow-wrap: break-word`
- [ ] Modal: `max-height: calc(100dvh - 2rem)` — не выходить за экран
- [ ] Gainers/Losers: горизонтальный скролл на одной строке, без overflow

### 1.6 Игровые страницы — Canvas Адаптация
- [ ] Все `<canvas>` элементы: `max-width: 100%; height: auto`
- [ ] Игровые кнопки управления: проверить что не выходят за экран
- [ ] Modals в играх (game over, pause): `max-width: calc(100vw - 2rem)`
- [ ] Snake: Кнопки D-pad — `position: fixed; bottom` с safe-area
- [ ] Cube Run / Race / Space Tunnel: touch-зоны в пределах экрана

### 1.7 Инструменты — Мобильная адаптация
- [ ] Crypto Calculator: все inputs `width: 100%`
- [ ] Todo list: items с `word-break: break-word`
- [ ] Calculator: кнопки сетка `grid-template-columns: repeat(4, 1fr)` — процентные ширины
- [ ] QR Generator: результат `max-width: 100%`
- [ ] Все `select`, `input` — min-height 48px для touch

---

## 🚀 ЧАСТЬ 2: Грандиозные Обновления ZETA 0.6

### 2.1 🏆 Система Достижений (Achievements)
**Описание:** Полная система медалей/ачивок за действия пользователя
- [ ] Создать `js/achievements.js` с системой трекинга
- [ ] Достижения:
  - 🐍 **"Змеиный Мастер"** — набрать 100 очков в Snake
  - 🎮 **"Геймер"** — сыграть во все 12 игр
  - 💎 **"Криптоман"** — просмотреть 20 разных криптовалют
  - ⭐ **"Коллекционер"** — добавить 10 криптовалют в избранное
  - 🏅 **"Level 5"** — достичь 5-го уровня XP
  - 🔧 **"Инструментальщик"** — использовать все 7 инструментов
  - 📖 **"Читатель"** — прочитать всю историю обновлений
  - 🔥 **"Ежедневный"** — заходить 7 дней подряд (daily streak)
- [ ] Popup уведомление при разблокировке достижения
- [ ] Страница достижений в Настройках или отдельная секция
- [ ] Бонус XP за каждое достижение (+50 XP)
- [ ] Данные хранить в `localStorage`

### 2.2 📊 Мини-Портфолио Трекер
**Описание:** Пользователь может "виртуально" добавлять крипто в портфель
- [ ] Кнопка "Добавить в портфель" на каждой крипто-карточке
- [ ] Modal для ввода количества монет
- [ ] Секция "Мой Портфель" на главной странице (под Hero)
- [ ] Показывать: общую стоимость, прибыль/убыток в %, рост за 24ч
- [ ] Хранить в `localStorage`
- [ ] Красивая анимация при изменении стоимости
- [ ] +30 XP за первое добавление в портфель

### 2.3 🌙 Ежедневный Совет Дня (Tip of the Day)
**Описание:** Каждый день новый совет о крипто, играх или технологиях
- [ ] Баннер на главной странице под Hero
- [ ] 30+ советов на 3 языках (uz, en, ru)
- [ ] Совет меняется каждый день (по дате)
- [ ] Можно закрыть, при следующем заходе появляется снова
- [ ] +5 XP за прочтение совета
- [ ] Красивый дизайн с иконкой 💡

### 2.4 🎮 Новая Игра: Flappy Jump
**Описание:** Простая но захватывающая игра в стиле Flappy Bird
- [ ] Создать `games/flappy.html`
- [ ] Canvas-based игра, тап/клик для прыжка
- [ ] Neon-стилистика в духе ZETA
- [ ] Pipe-генерация с увеличивающейся сложностью
- [ ] Highscore система с localStorage
- [ ] XP награды: +5 за каждые 10 очков
- [ ] Мобильные touch controls (тап по экрану — прыжок)
- [ ] Добавить карточку в `games.html`
- [ ] 100% мобильная адаптация

### 2.5 🔔 Визуальные Push-уведомления (In-App)
**Описание:** Красивые уведомления без использования системных push
- [ ] Улучшить систему `showNotification()` в `xp.js`
- [ ] Типы нотификаций: success, warning, info, achievement
- [ ] Стек уведомлений (если несколько одновременно — не перекрывают друг друга)
- [ ] Анимация slide-in сверху с auto-dismiss
- [ ] Звуковой эффект (если звук включён в настройках)

### 2.6 🎯 Daily Login Streak (Серия ежедневных входов)
**Описание:** Награды за ежедневные посещения
- [ ] Счётчик дней посещения подряд
- [ ] Бонусы XP: Day 1: +5, Day 3: +15, Day 7: +50, Day 14: +100, Day 30: +300
- [ ] Визуальная полоса прогресса на главной странице
- [ ] Если пропущен день — серия сбрасывается
- [ ] Красивый popup "День X — +N XP!"
- [ ] Хранение в localStorage (дата последнего входа + текущая серия)

### 2.7 🎨 Улучшенный UI/UX
- [ ] Плавные переходы между страницами (page transition effect)
- [ ] Pull-to-refresh жест на главной для обновления крипто (если PWA)
- [ ] Haptic feedback имитация через CSS animations
- [ ] Loading skeleton улучшить — добавить shimmer эффект
- [ ] Micro-animations на каждом интерактивном элементе

---

## 📝 ЧАСТЬ 3: Обновление Версий и Changelog

### 3.1 Файлы для обновления версии `0.5 → 0.6`

| Файл | Что обновить |
|------|-------------|
| `changelog.html` | Hero section: v0.5 → v0.6, текст обновлений, roadmap → v0.7. Сократить описание v0.5 |
| `settings.html` | `versionHistory` объект: добавить v0.6 как `current: true`, убрать current с v0.5 (все 3 языка) |
| `js/crypto.js` | Комментарий `ZETA v0.5` → `ZETA v0.6` |
| `js/lang.js` | `cl-roadmap` строки: `v0.5` → `v0.7` (следующая версия) |
| `changelog.html` | XP reward key: `zeta_changelog_reward_0.5` → `zeta_changelog_reward_0.6` |
| `changelog.html` | Timeline: добавить v0.6 как активный, v0.5 сделать обычным |
| `changelog.html` | Roadmap: обновить на v0.7 с новыми идеями |
| `changelog.html` | `copyUpdateText()` и `shareTelegram()`: обновить текст на v0.6 |

### 3.2 Контент для Changelog v0.6

**Заголовок:** `ZETA v0.6 — Grand Features 📱🚀`

**Список обновлений (для всех 3 языков):**
```
🔥 O'zbek:
📱  Mobile — barcha telefonlarga ideal moslashuv
🏆 Achievement tizimi — 8+ medal
📊 Mini Portfolio — kripto portfelingiz
💡 Kun maslahati — har kuni yangi maslahat
🎮 Yangi o'yin: Flappy Jump
🔥 Daily Streak — har kungi XP bonus
🎨 Yangilangan UI/UX animatsiyalar

🔥 English:
📱 Universal Mobile — perfect fit on any phone
🏆 Achievement system — 8+ medals
📊 Mini Portfolio — track your crypto
💡 Daily Tip — new tip every day
🎮 New game: Flappy Jump
🔥 Daily Streak — XP rewards
🎨 Enhanced UI/UX animations

🔥 Русский:
📱 Универсальный Мобильный — идеальный вид на любом телефоне
🏆 Система достижений — 8+ медалей
📊 Мини-Портфолио — следите за криптой
💡 Совет дня — новый совет каждый день
🎮 Новая игра: Flappy Jump
🔥 Ежедневная серия — XP бонусы
🎨 Обновлённый UI/UX с анимациями
```

### 3.3 Roadmap v0.7 (для changelog)
```
🎯 PWA — offline ishlash + install qilish
🤖 AI Chatbot — ZETA ichida yordamchi
🏪 XP Shop — XP bilan tema sotib olish
📈 Kripto ogohlantirishlari — narx o'zgarganda bildirishnoma
🌐 Multi-device sync — qurilmalar orasida sinxronizatsiya
```

---

## 📂 ЧАСТЬ 4: Порядок Реализации (Step-by-step)

### Фаза 1: 🔧 CSS Mobile Fix (Приоритет #1)
1. `style.css` — глобальные мобильные фиксы (breakpoints, safe-area, dvh)
2. `index.html` — проверить Hero, Crypto section, Modal
3. `games.html` — проверить grid, card sizing
4. `tools.html` — проверить grid, card sizing
5. `settings.html` — проверить форму настроек
6. `changelog.html` — timeline горизонтальный скролл
7. Все `games/*.html` — canvas, controls, game-over modals
8. Все `tools/*.html` — inputs, buttons, layouts

### Фаза 2: 🆕 Новые функции
1. `js/achievements.js` — система достижений
2. Daily Streak логика в `main.js` или отдельный файл
3. `games/flappy.html` — новая игра
4. Mini Portfolio (в `crypto.js` или отдельный файл)
5. Tip of the Day (в `main.js`)
6. Improved notifications (`xp.js`)

### Фаза 3: 📝 Version Updates
1. `changelog.html` — полное обновление
2. `settings.html` — versionHistory
3. `js/crypto.js` — комментарий версии
4. `js/lang.js` — roadmap строки

### Фаза 4: 🧪 Тестирование
1. Тест на iPhone SE (320px)
2. Тест на iPhone 12/13/14 (390px)
3. Тест на Samsung Galaxy S21 (360px)
4. Тест на iPad Mini (768px)
5. Тест в ландшафтном режиме
6. Тест всех 12 игр на мобильном
7. Тест всех 7 инструментов
8. Тест крипто секций (search, modal, details)
9. Тест достижений
10. Тест Daily Streak

---

## 📊 Сводка изменений

| Категория | Количество задач |
|-----------|-----------------|
| CSS / Responsive | ~25 задач |
| Новые функции | ~6 крупных фич |
| Version Updates | ~8 файлов |
| Тестирование | 10 тест-кейсов |
| **ИТОГО** | ~49+ задач |

---

## ⚡ Ключевые Принципы v0.6

1. **Ничего за экраном** — zero overflow на любом телефоне
2. **Touch-First** — все элементы min 48px для тач
3. **Производительность** — CSS вместо JS для адаптации
4. **3 языка** — все новые тексты на uz/en/ru
5. **XP за всё** — каждая новая фича даёт XP
6. **localStorage** — все данные локально, без бэкенда
